import os
from flask import Flask
from .database import init_db
from .auth.routes import auth_bp
from .main.routes import main_bp
from .appointments.routes import appointments_bp

def create_app():
    app = Flask(__name__, template_folder="../views", static_folder="../static")
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "troque-esta-chave-em-producao")
    app.config["DATABASE"] = os.path.join(app.root_path, "salao.db")

    init_db(app)
    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp, url_prefix="/admin")
    app.register_blueprint(appointments_bp, url_prefix="/admin")
    return app
