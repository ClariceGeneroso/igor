from datetime import date
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app
from ..database import get_db
from ..auth.decorators import admin_required

appointments_bp = Blueprint("appointments", __name__)
PROCEDURES = ["Corte", "Escova", "Tingimento"]

@appointments_bp.route("/painel")
@admin_required
def dashboard():
    with get_db(current_app) as db:
        appointments = db.execute("""
            SELECT * FROM appointments
            ORDER BY appointment_date ASC, appointment_time ASC
        """).fetchall()
    return render_template("dashboard.html", appointments=appointments)

@appointments_bp.route("/agendamentos/novo", methods=["GET", "POST"])
@admin_required
def new_appointment():
    if request.method == "POST":
        name = request.form.get("client_name", "").strip()
        phone = request.form.get("phone", "").strip()
        procedure = request.form.get("procedure", "")
        appointment_date = request.form.get("appointment_date", "")
        appointment_time = request.form.get("appointment_time", "")
        notes = request.form.get("notes", "").strip()

        if not all([name, phone, procedure, appointment_date, appointment_time]):
            flash("Preencha todos os campos obrigatórios.", "error")
        elif procedure not in PROCEDURES:
            flash("Procedimento inválido.", "error")
        elif appointment_date < date.today().isoformat():
            flash("Escolha uma data a partir de hoje.", "error")
        else:
            with get_db(current_app) as db:
                db.execute("""
                    INSERT INTO appointments
                    (client_name, phone, procedure, appointment_date, appointment_time, notes)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (name, phone, procedure, appointment_date, appointment_time, notes))
            flash("Agendamento cadastrado com sucesso!", "success")
            return redirect(url_for("appointments.dashboard"))
    return render_template("appointment_form.html", procedures=PROCEDURES, today=date.today().isoformat())

@appointments_bp.route("/agendamentos/<int:appointment_id>/status", methods=["POST"])
@admin_required
def update_status(appointment_id):
    status = request.form.get("status")
    if status not in ["Agendado", "Concluído", "Cancelado"]:
        flash("Status inválido.", "error")
    else:
        with get_db(current_app) as db:
            db.execute("UPDATE appointments SET status = ? WHERE id = ?", (status, appointment_id))
        flash("Status atualizado.", "success")
    return redirect(url_for("appointments.dashboard"))

@appointments_bp.route("/agendamentos/<int:appointment_id>/excluir", methods=["POST"])
@admin_required
def delete_appointment(appointment_id):
    with get_db(current_app) as db:
        db.execute("DELETE FROM appointments WHERE id = ?", (appointment_id,))
    flash("Agendamento excluído.", "success")
    return redirect(url_for("appointments.dashboard"))
