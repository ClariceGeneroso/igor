from functools import wraps
from flask import session, redirect, url_for, flash

def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("admin_id"):
            flash("Faça login para acessar essa área.", "error")
            return redirect(url_for("auth.login"))
        return view(*args, **kwargs)
    return wrapped
