from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import check_password_hash
from ..database import get_db
from flask import current_app

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if session.get("admin_id"):
        return redirect(url_for("appointments.dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        with get_db(current_app) as db:
            admin = db.execute("SELECT * FROM admins WHERE username = ?", (username,)).fetchone()
        if admin and check_password_hash(admin["password_hash"], password):
            session.clear()
            session["admin_id"] = admin["id"]
            session["admin_username"] = admin["username"]
            return redirect(url_for("appointments.dashboard"))
        flash("Usuário ou senha inválidos.", "error")
    return render_template("login.html")

@auth_bp.route("/logout")
def logout():
    session.clear()
    flash("Você saiu do painel administrativo.", "success")
    return redirect(url_for("main.index"))
