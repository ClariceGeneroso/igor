# Studio Bella — Sistema de salão de beleza

Aplicação web de exemplo feita com **Python, Flask e SQLite3**.

## 1. Requisitos
- Python 3.10 ou superior
- pip
- Navegador atualizado

## 2. Extrair e abrir o projeto
Extraia `salao_beleza.zip`. Abra o terminal dentro da pasta `salao_beleza`.

## 3. Criar ambiente virtual (recomendado)

Linux/macOS:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

Windows:
```powershell
py -m venv .venv
.venv\Scripts\activate
```

## 4. Instalar dependências
```bash
pip install -r requirements.txt
```

## 5. Executar
```bash
python run.py
```
Acesse: http://127.0.0.1:5000

O banco `app/salao.db` é criado automaticamente na primeira execução.

## 6. Acesso inicial do administrador
- Usuário: `admin`
- Senha: `admin123`

Entre em **Administrador** para abrir o painel e gerenciar os agendamentos. Troque a senha padrão antes de usar o sistema de verdade.

## 7. Estrutura de pastas
```text
salao_beleza/
├── app/
│   ├── __init__.py
│   ├── database.py
│   ├── auth/
│   │   ├── __init__.py
│   │   ├── routes.py
│   │   └── decorators.py
│   ├── main/
│   │   ├── __init__.py
│   │   └── routes.py
│   └── appointments/
│       ├── __init__.py
│       └── routes.py
├── views/
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── appointment_form.html
│   └── dashboard.html
├── static/css/style.css
├── requirements.txt
└── run.py
```

## 8. Como funciona
- `run.py`: inicia o servidor Flask.
- `app/__init__.py`: configura a aplicação e registra os Blueprints.
- `database.py`: cria as tabelas e fornece conexão SQLite.
- `auth/`: login, logout e proteção das páginas administrativas.
- `main/`: página inicial pública.
- `appointments/`: cadastro, listagem, atualização de status e exclusão de agendamentos.
- `views/`: páginas HTML com Jinja2.
- `static/css/`: estilos visuais.

## Observações
- As fotos da página inicial e a fonte são carregadas de serviços externos; é necessário ter internet para exibi-las.
- Este é um projeto inicial para estudo. Antes de publicar, configure uma `SECRET_KEY` forte, altere a senha padrão, habilite HTTPS e implemente proteção CSRF e regras de disponibilidade/choque de horários.
- O sistema valida campos obrigatórios e impede cadastro de data passada, mas ainda não impede dois clientes de escolherem o mesmo horário.
