# Sistema de recomendações e avaliações de séries

Projeto Flask + SQLite, organizado em MVC, com templates na pasta `app/views`.

## Requisitos
- Python 3.10 ou superior
- Flask e Werkzeug (instalados pelo `requirements.txt`)

## Instalação no Linux
Abra o terminal dentro da pasta `series` e execute:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python init_db.py
python run.py
```

Acesse `http://127.0.0.1:5000/register`, crie uma conta e depois entre em `http://127.0.0.1:5000/login`.

## Responsabilidades
- `app/database.py`: classe `ConexaoDB`, responsável por abrir a conexão, confirmar ou desfazer a transação e fechar a conexão.
- `init_db.py`: único arquivo que cria as tabelas `users` e `series`.
- `app/models/`: operações de banco de dados (CRUD), sem criação de tabelas.
- `app/controllers/`: rotas e fluxo da aplicação.
- `app/views/`: páginas HTML/Jinja2.

## Banco de dados existente
O inicializador reconhece a estrutura antiga de `users` que usava a coluna `password_hash` e migra os hashes para a coluna `password`, preservando os usuários. Faça uma cópia de segurança do arquivo `meu_sistema.db` antes de executar a inicialização sobre um banco já existente.

Se não existir banco, o SQLite criará `meu_sistema.db` automaticamente ao executar `python init_db.py`.

## Segurança
A chave secreta padrão é apenas para desenvolvimento. Antes de publicar, defina uma variável de ambiente `SECRET_KEY` forte e desative o modo debug.
