"""Cria e atualiza a estrutura do banco. Execute com: python init_db.py"""
from app.database import ConexaoDB


def inicializar_banco():
    with ConexaoDB() as db:
        # Migração simples da versão antiga, que usava password_hash.
        tabela = db.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'users'"
        ).fetchone()

        if tabela:
            colunas = {
                linha["name"]
                for linha in db.execute("PRAGMA table_info(users)").fetchall()
            }

            if "password_hash" in colunas and "password" not in colunas:
                db.execute("ALTER TABLE users RENAME TO users_legacy")
                db.execute("""
                    CREATE TABLE users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        nome TEXT NOT NULL DEFAULT '',
                        email TEXT NOT NULL DEFAULT '',
                        username TEXT NOT NULL UNIQUE,
                        password TEXT NOT NULL
                    )
                """)
                db.execute("""
                    INSERT INTO users (id, nome, email, username, password)
                    SELECT id, '', '', username, password_hash
                    FROM users_legacy
                """)
                db.execute("DROP TABLE users_legacy")
            else:
                if "nome" not in colunas:
                    db.execute("ALTER TABLE users ADD COLUMN nome TEXT NOT NULL DEFAULT ''")
                if "email" not in colunas:
                    db.execute("ALTER TABLE users ADD COLUMN email TEXT NOT NULL DEFAULT ''")
        else:
            db.execute("""
                CREATE TABLE users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome TEXT NOT NULL DEFAULT '',
                    email TEXT NOT NULL DEFAULT '',
                    username TEXT NOT NULL UNIQUE,
                    password TEXT NOT NULL
                )
            """)

        # Todas as demais tabelas são criadas exclusivamente neste arquivo.
        db.execute("""
            CREATE TABLE IF NOT EXISTS series (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                titulo TEXT NOT NULL,
                genero TEXT NOT NULL,
                temporadas INTEGER NOT NULL CHECK (temporadas >= 1)
            )
        """)

    print("Banco de dados inicializado com sucesso!")


if __name__ == "__main__":
    inicializar_banco()
