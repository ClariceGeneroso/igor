from app.database import ConexaoDB


class SerieModel:
    def __init__(self, id=None, titulo=None, genero=None, temporadas=None):
        self.id = id
        self.titulo = titulo
        self.genero = genero
        self.temporadas = temporadas

    def inserir(self):
        with ConexaoDB() as db:
            cursor = db.execute(
                """INSERT INTO series (titulo, genero, temporadas)
                   VALUES (?, ?, ?)""",
                (self.titulo, self.genero, int(self.temporadas)),
            )
            self.id = cursor.lastrowid
        return self.id

    @staticmethod
    def listar_todas():
        with ConexaoDB() as db:
            rows = db.execute(
                """SELECT id, titulo, genero, temporadas
                   FROM series ORDER BY titulo COLLATE NOCASE"""
            ).fetchall()

        return [
            SerieModel(
                id=row["id"],
                titulo=row["titulo"],
                genero=row["genero"],
                temporadas=row["temporadas"],
            )
            for row in rows
        ]

    @staticmethod
    def buscar_por_id(serie_id):
        with ConexaoDB() as db:
            row = db.execute(
                "SELECT id, titulo, genero, temporadas FROM series WHERE id = ?",
                (serie_id,),
            ).fetchone()

        if row is None:
            return None

        return SerieModel(
            id=row["id"],
            titulo=row["titulo"],
            genero=row["genero"],
            temporadas=row["temporadas"],
        )

    def atualizar(self):
        with ConexaoDB() as db:
            cursor = db.execute(
                """UPDATE series
                   SET titulo = ?, genero = ?, temporadas = ?
                   WHERE id = ?""",
                (self.titulo, self.genero, int(self.temporadas), self.id),
            )
        return cursor.rowcount > 0

    @staticmethod
    def deletar(serie_id):
        with ConexaoDB() as db:
            cursor = db.execute("DELETE FROM series WHERE id = ?", (serie_id,))
        return cursor.rowcount > 0
