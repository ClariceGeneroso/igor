from .user_model import UserModel
from .serie_model import SerieModel

__all__ = ["UserModel", "SerieModel"]
