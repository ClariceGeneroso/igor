from werkzeug.security import generate_password_hash
from app.database import ConexaoDB


class UserModel:
    def __init__(self, id=None, nome="", username=None, password=None, email=None):
        self.id = id
        self.nome = nome or ""
        self.username = username
        self.password = password
        self.email = email or ""

    def inserir(self):
        if not self.username or not self.password:
            raise ValueError("Usuário e senha são obrigatórios.")

        senha_hash = generate_password_hash(self.password)
        with ConexaoDB() as db:
            cursor = db.execute(
                """INSERT INTO users (nome, email, username, password)
                   VALUES (?, ?, ?, ?)""",
                (self.nome, self.email, self.username, senha_hash),
            )
            self.id = cursor.lastrowid
        return self.id

    @classmethod
    def get_by_username(cls, username):
        with ConexaoDB() as db:
            row = db.execute(
                """SELECT id, nome, email, username, password
                   FROM users WHERE username = ?""",
                (username,),
            ).fetchone()

        if row is None:
            return None

        return cls(
            id=row["id"],
            nome=row["nome"],
            email=row["email"],
            username=row["username"],
            password=row["password"],
        )
