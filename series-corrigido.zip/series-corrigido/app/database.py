import os
import sqlite3

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "meu_sistema.db")


class ConexaoDB:
    """Gerencia abertura, transação e fechamento de uma conexão SQLite."""

    def __init__(self, caminho=DB_PATH):
        self.caminho = caminho
        self.conexao = None

    def __enter__(self):
        self.conexao = sqlite3.connect(self.caminho)
        self.conexao.row_factory = sqlite3.Row
        self.conexao.execute("PRAGMA foreign_keys = ON")
        return self.conexao

    def __exit__(self, tipo_erro, erro, traceback):
        try:
            if tipo_erro is None:
                self.conexao.commit()
            else:
                self.conexao.rollback()
        finally:
            if self.conexao is not None:
                self.conexao.close()
        return False
