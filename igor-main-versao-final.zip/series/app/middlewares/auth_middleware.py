from functools import wraps
from flask import session, redirect, url_for, flash

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            flash("Faça login para continuar.", "warning")
            return redirect(url_for("auth.login"))
        return f(*args, **kwargs)
    return wrapper

def guest_only(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if session.get("user_id"):
            return redirect(url_for("main.dashboard"))
        return f(*args, **kwargs)
    return wrapper

def init_auth_middleware(app):
    # Rotas aplicam login_required/checagem de sessão individualmente.
    return app
