import os
from flask import Flask, redirect, url_for
from app.database import DB_PATH

def create_app(test_config=None):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    app = Flask(__name__, template_folder=os.path.join(base_dir, "views"), static_folder=os.path.join(base_dir, "static"))
    app.config.update(SECRET_KEY=os.environ.get("SECRET_KEY", "dev-chave-trocar-em-producao"), DATABASE=DB_PATH)
    if test_config:
        app.config.update(test_config)
    from app.controllers.auth_controller import auth_bp
    from app.controllers.main_controller import main_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    @app.route("/health")
    def health(): return {"status": "ok"}
    return app
