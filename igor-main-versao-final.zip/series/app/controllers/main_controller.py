from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from app.models.serie_model import SerieModel

main_bp = Blueprint("main", __name__)

def autenticado():
    return bool(session.get("user_id"))

def exigir_login():
    if not autenticado():
        flash("Faça login para continuar.", "warning")
        return redirect(url_for("auth.login"))
    return None

@main_bp.route("/")
def dashboard():
    bloqueio = exigir_login()
    if bloqueio: return bloqueio
    return render_template("dashboard.html", series=SerieModel.listar_todas())

@main_bp.route("/series/nova", methods=["GET", "POST"])
def cadastrar_serie():
    bloqueio = exigir_login()
    if bloqueio: return bloqueio
    if request.method == "POST":
        titulo = request.form.get("titulo", "").strip()
        genero = request.form.get("genero", "").strip()
        try:
            temporadas = int(request.form.get("temporadas", ""))
            if not titulo or not genero or temporadas < 1: raise ValueError
            SerieModel(titulo=titulo, genero=genero, temporadas=temporadas).inserir()
            flash("Série cadastrada com sucesso!", "success")
            return redirect(url_for("main.dashboard"))
        except (ValueError, TypeError):
            flash("Informe título, gênero e temporadas (número maior que zero).", "danger")
    return render_template("register_serie.html")

@main_bp.route("/series/editar/<int:id>", methods=["GET", "POST"])
def editar_serie(id):
    bloqueio = exigir_login()
    if bloqueio: return bloqueio
    serie = SerieModel.buscar_por_id(id)
    if not serie: return "Série não encontrada", 404
    if request.method == "POST":
        titulo = request.form.get("titulo", "").strip()
        genero = request.form.get("genero", "").strip()
        try:
            temporadas = int(request.form.get("temporadas", ""))
            if not titulo or not genero or temporadas < 1: raise ValueError
            serie.titulo, serie.genero, serie.temporadas = titulo, genero, temporadas
            serie.atualizar()
            flash("Série atualizada!", "success")
            return redirect(url_for("main.dashboard"))
        except (ValueError, TypeError):
            flash("Confira os dados da série.", "danger")
    return render_template("edit_serie.html", serie=serie)

@main_bp.route("/series/remover/<int:id>", methods=["POST"])
def remover_serie(id):
    bloqueio = exigir_login()
    if bloqueio: return bloqueio
    SerieModel.deletar(id)
    flash("Série removida.", "success")
    return redirect(url_for("main.dashboard"))
