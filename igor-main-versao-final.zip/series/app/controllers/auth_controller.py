from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from werkzeug.security import check_password_hash
from app.models.user_model import UserModel

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect(url_for("main.dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = UserModel.get_by_username(username)
        valido = False
        if user and user.password:
            try:
                valido = check_password_hash(user.password, password)
            except (ValueError, TypeError):
                valido = False
        if valido:
            session.clear()
            session["user_id"] = user.id
            session["username"] = user.username
            return redirect(url_for("main.dashboard"))
        flash("Usuário ou senha incorretos.", "danger")
    return render_template("login.html")

@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if session.get("user_id"):
        return redirect(url_for("main.dashboard"))
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        email = request.form.get("email", "").strip()
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not all([nome, email, username, password]):
            flash("Preencha todos os campos.", "danger")
        elif len(password) < 4:
            flash("A senha precisa ter pelo menos 4 caracteres.", "danger")
        else:
            try:
                UserModel(nome=nome, email=email, username=username, password=password).inserir()
                flash("Conta criada! Entre com seu usuário e senha.", "success")
                return redirect(url_for("auth.login"))
            except Exception as exc:
                if "UNIQUE constraint failed" in str(exc):
                    flash("Esse usuário já existe. Escolha outro.", "danger")
                else:
                    flash("Não foi possível criar a conta. Confira o terminal para detalhes.", "danger")
                    raise
    return render_template("register.html")

@auth_bp.route("/logout", methods=["GET", "POST"])
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
