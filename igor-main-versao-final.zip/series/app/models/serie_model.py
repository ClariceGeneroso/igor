from app.database import conectar

class SerieModel:
    def __init__(self, id=None, titulo=None, genero=None, temporadas=None):
        self.id = id
        self.titulo = titulo
        self.genero = genero
        self.temporadas = temporadas

    @staticmethod
    def criar_tabela():
        with conectar() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS series (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                titulo TEXT NOT NULL,
                genero TEXT NOT NULL,
                temporadas INTEGER NOT NULL CHECK (temporadas >= 1)
            )""")
            db.commit()

    def inserir(self):
        self.criar_tabela()
        with conectar() as db:
            db.execute("INSERT INTO series (titulo, genero, temporadas) VALUES (?, ?, ?)", (self.titulo, self.genero, int(self.temporadas)))
            db.commit()

    @staticmethod
    def listar_todas():
        SerieModel.criar_tabela()
        with conectar() as db:
            rows = db.execute("SELECT id, titulo, genero, temporadas FROM series ORDER BY titulo COLLATE NOCASE").fetchall()
        return [SerieModel(id=r["id"], titulo=r["titulo"], genero=r["genero"], temporadas=r["temporadas"]) for r in rows]

    @staticmethod
    def buscar_por_id(serie_id):
        SerieModel.criar_tabela()
        with conectar() as db:
            r = db.execute("SELECT id, titulo, genero, temporadas FROM series WHERE id = ?", (serie_id,)).fetchone()
        return SerieModel(id=r["id"], titulo=r["titulo"], genero=r["genero"], temporadas=r["temporadas"]) if r else None

    def atualizar(self):
        with conectar() as db:
            db.execute("UPDATE series SET titulo = ?, genero = ?, temporadas = ? WHERE id = ?", (self.titulo, self.genero, int(self.temporadas), self.id))
            db.commit()

    @staticmethod
    def deletar(serie_id):
        with conectar() as db:
            db.execute("DELETE FROM series WHERE id = ?", (serie_id,))
            db.commit()
