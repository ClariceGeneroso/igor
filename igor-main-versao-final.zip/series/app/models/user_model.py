from werkzeug.security import generate_password_hash
from app.database import conectar

class UserModel:
    def __init__(self, id=None, nome="", username=None, password=None, email=None):
        self.id = id
        self.nome = nome or ""
        self.username = username
        self.password = password
        self.email = email

    @classmethod
    def criar_tabela(cls):
        with conectar() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL DEFAULT '',
                email TEXT NOT NULL DEFAULT '',
                username TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL
            )""")
            db.commit()

    def inserir(self):
        self.criar_tabela()
        if not self.username or not self.password:
            raise ValueError("Usuário e senha são obrigatórios.")
        senha_hash = generate_password_hash(self.password)
        with conectar() as db:
            db.execute(
                "INSERT INTO users (nome, email, username, password) VALUES (?, ?, ?, ?)",
                (self.nome, self.email or "", self.username, senha_hash)
            )
            db.commit()

    @classmethod
    def get_by_username(cls, username):
        cls.criar_tabela()
        with conectar() as db:
            row = db.execute("SELECT id, nome, email, username, password FROM users WHERE username = ?", (username,)).fetchone()
        if row is None:
            return None
        return cls(id=row["id"], nome=row["nome"], email=row["email"], username=row["username"], password=row["password"])
