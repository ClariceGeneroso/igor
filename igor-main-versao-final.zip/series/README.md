# Sistema de recomendações e avaliações de séries (base funcional)

## Requisitos
Python 3.10 ou superior. O projeto usa Flask e SQLite; não precisa instalar servidor de banco.

## Executar no Linux
Na pasta que contém `run.py`:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python init_db.py
python run.py
```

Abra http://127.0.0.1:5000/register, crie uma conta e depois entre em http://127.0.0.1:5000/login.
O banco `meu_sistema.db` é criado na pasta `series`. Não apague esse arquivo se quiser preservar cadastros.

## Funcionalidades nesta versão
- cadastro de conta com senha armazenada em hash;
- login/logout por sessão;
- painel protegido;
- cadastro, listagem, edição e remoção de séries;
- templates em `app/views`;
- banco SQLite com caminho único.

A aplicação está configurada para desenvolvimento (`debug=True` em run.py). Não publique na internet sem trocar a SECRET_KEY e revisar a configuração de produção.
