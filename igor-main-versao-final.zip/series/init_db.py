from app.models.user_model import UserModel
from app.models.serie_model import SerieModel

if __name__ == "__main__":
    UserModel.criar_tabela()
    SerieModel.criar_tabela()
    print("Banco inicializado com sucesso.")
