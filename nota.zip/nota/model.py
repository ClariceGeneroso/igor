import sqlite3

class Produto:

  def __init__(self, id=None, nome=None, preco=None):
    self.id = id
    self.nome = nome
    self.preco = preco
    self.criar_tabela()

  def conectar(self):
    conexao = sqlite3.connect('database.db')
    conexao.row_factory = sqlite3.Row
    return conexao

  def criar_tabela(self):
    conexao = self.conectar()
    cursor = conexao.cursor()
    cursor.execute("""
            CREATE TABLE IF NOT EXISTS produtos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                preco REAL NOT NULL
            )
        """)
    conexao.commit()
    conexao.close()

  def inserir(self):
    conexao = self.conectar()
    cursor = conexao.cursor()
    cursor.execute(
        "INSERT INTO produtos (nome, preco) VALUES (?, ?)",
        (self.nome, self.preco),
    )
    conexao.commit()
    conexao.close()

  @staticmethod
  def listar_todos():
    conexao = sqlite3.connect('database.db')
    conexao.row_factory = sqlite3.Row
    cursor = conexao.cursor()
    
    # Garante que a tabela existe antes de executar o SELECT
    cursor.execute("""
            CREATE TABLE IF NOT EXISTS produtos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                preco REAL NOT NULL
            )
        """)
    
    cursor.execute("SELECT * FROM produtos")
    registros = cursor.fetchall()
    conexao.close()
    return registros