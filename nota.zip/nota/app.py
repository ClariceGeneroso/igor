from flask import Flask, redirect, render_template, request, url_for
from model import Produto

app = Flask(__name__)


@app.route('/')
def index():
  return render_template('listar.html', produtos=Produto.listar_todos())


@app.route('/cadastrar', methods=['GET', 'POST'])
def cadastrar():
  if request.method == 'POST':
    # 1. Recebe os dados do formulário HTML
    nome = request.form['nome']
    preco = request.form['preco']

    # 2. Instancia a classe passando os dados
    novo_produto = Produto(nome=nome, preco=preco)

    # 3. Chama o método da classe para salvar no banco
    novo_produto.inserir()

    # 4. Redireciona para a página de listagem
    return redirect(url_for('listar'))

  return render_template('cadastrar.html')


@app.route('/listar')
def listar():
  # Busca os dados diretamente do banco usando o método da classe
  produtos = Produto.listar_todos()
  return render_template('listar.html', produtos=produtos)


if __name__ == '__main__':
  app.run(debug=True)